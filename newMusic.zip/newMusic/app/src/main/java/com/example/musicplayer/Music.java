package com.example.musicplayer;

public class Music {
    private String musicName;

    public Music(String name) {
        this.musicName = name;
    }
    public String getMusicName() {
        return musicName;
    }

    public void setMusicName(String musicName) {
        this.musicName = musicName;
    }
}
